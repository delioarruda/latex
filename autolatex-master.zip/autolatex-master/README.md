# pylatex
Presentation about automatic PDF generation with Python+LaTeX

## When/where was this presented?

- FISL2013

## **Installing all dependencies**
#### Debian
```
sudo apt-get install texlive-full texlive-latex-base
```
